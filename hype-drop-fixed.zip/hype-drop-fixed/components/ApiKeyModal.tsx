import React, { useState } from 'react';
import { Button } from './Button';

interface ApiKeyModalProps {
  onConfirm: (key: string, isPro: boolean) => void;
}

export const ApiKeyModal: React.FC<ApiKeyModalProps> = ({ onConfirm }) => {
  const [key, setKey] = useState('');
  const [isPro, setIsPro] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = () => {
    const trimmed = key.trim();
    if (!trimmed) {
      setError('Please enter a valid Gemini API key.');
      return;
    }
    onConfirm(trimmed, isPro);
  };

  const handleSkip = () => {
    // Use flash model with an empty key — will fail gracefully at call time
    // but let the user try with env var if they have one set
    const envKey = (window as any).__GEMINI_API_KEY__ || '';
    onConfirm(envKey || 'no-key', false);
  };

  return (
    <div className="fixed inset-0 z-[200] flex items-center justify-center p-4 bg-black/90 backdrop-blur-2xl">
      <div className="relative bg-[#0a0a0a] border border-white/10 rounded-3xl w-full max-w-md overflow-hidden shadow-2xl animate-fade-in ring-1 ring-white/5">
        
        {/* Header */}
        <div className="p-8 pb-0">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-lime-400/10 border border-lime-400/20 rounded-xl flex items-center justify-center">
              <svg className="w-5 h-5 text-lime-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 7a2 2 0 012 2m4 0a6 6 0 01-7.743 5.743L11 17H9v2H7v2H4a1 1 0 01-1-1v-2.586a1 1 0 01.293-.707l5.964-5.964A6 6 0 1121 9z" />
              </svg>
            </div>
            <div>
              <h2 className="text-xl font-bold text-white brand-font uppercase tracking-wide">API Key Setup</h2>
              <p className="text-[10px] text-gray-500 uppercase tracking-widest font-medium">SPNK Studio · Gemini AI</p>
            </div>
          </div>
          <p className="text-sm text-gray-400 leading-relaxed mb-6">
            Enter your <span className="text-white font-medium">Google Gemini API key</span> to power image generation. 
            Get a free key at <a href="https://aistudio.google.com" target="_blank" rel="noreferrer" className="text-lime-400 hover:underline">aistudio.google.com</a>.
          </p>
        </div>

        {/* Body */}
        <div className="p-8 pt-4 space-y-5">
          
          {/* Key input */}
          <div>
            <label className="text-[10px] font-bold text-gray-500 uppercase tracking-widest mb-2 block">Gemini API Key</label>
            <input
              type="password"
              value={key}
              onChange={e => { setKey(e.target.value); setError(''); }}
              onKeyDown={e => e.key === 'Enter' && handleSubmit()}
              placeholder="AIza..."
              className="w-full bg-black/60 border border-white/10 text-white text-sm rounded-xl py-3 px-4 focus:outline-none focus:border-lime-400/60 focus:ring-1 focus:ring-lime-400/40 transition-all placeholder-gray-700 font-mono"
            />
            {error && <p className="text-red-400 text-xs mt-2">{error}</p>}
          </div>

          {/* Model tier toggle */}
          <div className="bg-black/40 rounded-2xl p-4 border border-white/5">
            <div className="flex items-start justify-between gap-4">
              <div>
                <p className="text-xs font-bold text-white mb-1">Use Gemini 2.5 Pro</p>
                <p className="text-[10px] text-gray-500 leading-relaxed">
                  Best quality renders. Requires a <span className="text-amber-400">paid API key</span> with Pro model access.<br/>
                  Free keys use <span className="text-lime-400">Gemini 2.5 Flash</span> (still good).
                </p>
              </div>
              <button
                onClick={() => setIsPro(p => !p)}
                className={`shrink-0 w-12 h-6 rounded-full transition-all duration-300 relative mt-0.5 ${isPro ? 'bg-lime-400' : 'bg-white/10'}`}
              >
                <div className={`absolute top-1 w-4 h-4 rounded-full bg-white shadow transition-all duration-300 ${isPro ? 'left-7' : 'left-1'}`} />
              </button>
            </div>
            {isPro && (
              <div className="mt-3 pt-3 border-t border-white/5">
                <div className="flex items-center gap-2 text-[10px] text-amber-400/80 font-medium">
                  <svg className="w-3 h-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Using: gemini-2.5-pro-preview-06-05
                </div>
              </div>
            )}
            {!isPro && (
              <div className="mt-3 pt-3 border-t border-white/5">
                <div className="flex items-center gap-2 text-[10px] text-lime-400/80 font-medium">
                  <svg className="w-3 h-3 shrink-0" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M13 16h-1v-4h-1m1-4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  Using: gemini-2.5-flash-preview-05-20
                </div>
              </div>
            )}
          </div>

          <Button variant="accent" onClick={handleSubmit} className="w-full py-4 text-sm rounded-2xl shadow-[0_0_20px_rgba(163,230,53,0.15)]">
            <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m6 2a9 9 0 11-18 0 9 9 0 0118 0z" />
            </svg>
            Launch Studio
          </Button>

          <button onClick={handleSkip} className="w-full text-center text-[10px] text-gray-600 hover:text-gray-400 transition-colors uppercase tracking-widest font-medium py-1">
            Skip (use environment variable / test mode)
          </button>
        </div>

      </div>
    </div>
  );
};
