import { GoogleGenAI, Type } from "@google/genai";
import { LightingSettings, FabricType, BackgroundOption, ModelMode, ModelGender, CompositionType, GarmentType, CustomBackground, FitType, ShotAngle } from "../types";

// ─────────────────────────────────────────────
// CORRECT MODEL NAMES (as of mid-2025)
// ─────────────────────────────────────────────
// gemini-2.0-flash               → fast text only, no image gen
// gemini-2.5-flash-preview-05-20 → image generation (free tier works)
// gemini-2.5-pro-preview-06-05   → best quality image gen (Pro key)
// ─────────────────────────────────────────────

const MODEL_PRO   = "gemini-2.5-pro-preview-06-05";
const MODEL_FLASH = "gemini-2.5-flash-preview-05-20";
const MODEL_TEXT  = "gemini-2.0-flash";

// Global API key + tier — set by ApiKeyModal on load
let _apiKey: string = "";
let _useProModel: boolean = false;

export const setApiKey = (key: string, isPro: boolean) => {
  _apiKey = key;
  _useProModel = isPro;
};
export const getApiKey = () => _apiKey;
export const isProModel = () => _useProModel;

const getAI = () => {
  if (!_apiKey) throw new Error("No API key configured. Please reload and enter your Gemini API key.");
  return new GoogleGenAI({ apiKey: _apiKey });
};
const getImageModel = () => (_useProModel ? MODEL_PRO : MODEL_FLASH);

// ─────────────────────────────────────────────
// SHOT ANGLE DEFINITIONS
// ─────────────────────────────────────────────
const shotAngleInstructions: Record<ShotAngle, string> = {
  front:                "Camera: Direct front-facing (0°). Subject faces camera. Both sleeves symmetrically visible.",
  three_quarter_front:  "Camera: 45° three-quarter front. Subject turned slightly left. Front design visible with depth.",
  side_left:            "Camera: 90° left side profile. Pure left silhouette. Right side not visible.",
  side_right:           "Camera: 90° right side profile. Pure right silhouette. Left side not visible.",
  three_quarter_back:   "Camera: 45° three-quarter back. Subject turned away. Back panel + partial side visible.",
  back:                 "Camera: Direct rear (180°). Full back of garment. Back print/details are the hero.",
};

// ─────────────────────────────────────────────
// AD COPY
// ─────────────────────────────────────────────
export const generateAdCopy = async (base64Image: string, mimeType: string) => {
  const ai = getAI();

  const systemInstruction = `
    You are a social media manager for a hype streetwear brand targeting Gen Z.
    Generate 5 distinct ad copy options:
    1. 'witty': Heavy internet slang, emojis, high energy.
    2. 'edgy': Dark, rebellious, punchy. Focus on non-conformity.
    3. 'minimalist': Clean aesthetic, comfort, fit, materials. Effortless tone.
    4. 'sarcastic': Deadpan self-aware, slightly roasting hype culture.
    5. 'aspirational': High-status, exclusive, "you've made it" lifestyle.
    Output JSON only.
  `;

  const adCopyProperties = {
    headline: { type: Type.STRING },
    body:     { type: Type.STRING },
    hashtags: { type: Type.ARRAY, items: { type: Type.STRING } }
  };

  const response = await ai.models.generateContent({
    model: MODEL_TEXT,
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType } },
        { text: "Analyze this item and write ad copy variations." },
      ],
    },
    config: {
      systemInstruction,
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          witty:        { type: Type.OBJECT, properties: adCopyProperties, required: ["headline", "body", "hashtags"] },
          edgy:         { type: Type.OBJECT, properties: adCopyProperties, required: ["headline", "body", "hashtags"] },
          minimalist:   { type: Type.OBJECT, properties: adCopyProperties, required: ["headline", "body", "hashtags"] },
          sarcastic:    { type: Type.OBJECT, properties: adCopyProperties, required: ["headline", "body", "hashtags"] },
          aspirational: { type: Type.OBJECT, properties: adCopyProperties, required: ["headline", "body", "hashtags"] },
        },
        required: ["witty", "edgy", "minimalist", "sarcastic", "aspirational"],
      },
    },
  });

  return response.text ? JSON.parse(response.text) : null;
};

// ─────────────────────────────────────────────
// COMPOSITION
// ─────────────────────────────────────────────
const getLuxuryCompositionStrategy = (): string => `
  COMPOSITION:
  - 85mm prime equivalent lens. No barrel distortion.
  - Aperture f/4.0–f/5.6. Full garment in sharp focus — no depth-of-field blur on product.
  - Camera height: eye-level. Horizon at garment midpoint.
  - Garment fills ~70% of frame. 15% breathing room on all sides.
  - DO NOT crop any edge of the garment.
`;

// ─────────────────────────────────────────────
// 3D CLOTHING GENERATION
// ─────────────────────────────────────────────
export const generate3DClothing = async (
  base64Image: string,
  mimeType: string,
  lighting: LightingSettings,
  fabricType: FabricType,
  garmentType: GarmentType,
  fitType: FitType,
  secondaryFabricType: FabricType | 'none' = 'none',
  background: BackgroundOption = 'minimal_luxury',
  modelMode: ModelMode = 'ghost',
  modelGender: ModelGender = 'neutral',
  composition: CompositionType = 'golden_ratio',
  customBackground?: CustomBackground,
  shotAngle: ShotAngle = 'front'
): Promise<string | null> => {
  const ai = getAI();
  const model = getImageModel();

  const dirMap: Record<string, string> = { front: 'Butterfly', left: 'Rembrandt-left', right: 'Rembrandt-right', top: 'Top-down' };
  const mainLightDesc = modelMode === 'human'
    ? `${lighting.main.intensity} ${lighting.main.color} ${dirMap[lighting.main.direction]} lighting.`
    : `${lighting.main.intensity} softbox from ${lighting.main.direction}. Diffused product lighting.`;
  const rimLightDesc = lighting.rim.intensity !== 'none'
    ? `${lighting.rim.intensity} ${lighting.rim.color} rim light from ${lighting.rim.direction}.`
    : "No rim light.";
  const shadowHardness = lighting.main.intensity === 'hard' ? "Hard contact shadow" : "Soft diffused shadow";

  let backgroundPrompt = "";
  let shadowInstructions = "";

  if (customBackground) {
    if (customBackground.type === 'color') {
      backgroundPrompt = `ENVIRONMENT: Solid color ${customBackground.value} seamless infinity curve. Floor matches. Global illumination bounces ${customBackground.value} tint onto garment base.`;
      shadowInstructions = `${shadowHardness} in multiply blend over ${customBackground.value}. No grey shadows.`;
    } else {
      backgroundPrompt = `ENVIRONMENT: Composite subject into Background Image 2. Match camera angle, perspective, lens distortion. Estimate light source from background and apply to subject.`;
      shadowInstructions = `Cast realistic ground shadows matching existing shadows in background image.`;
    }
  } else {
    const presets: Record<BackgroundOption, string> = {
      minimal_luxury:    "High-end grey plaster cyclorama. Soft diffused ambient fill. Studio white balance.",
      sunlit_travertine: "Warm beige travertine stone wall. Dappled leaf shadow overlay. Golden-hour warmth.",
      urban_concrete:    "Raw industrial concrete wall. Cool neutral ambient. No fill light.",
      moody_editorial:   "Near-black charcoal void. High contrast. Single hard key. Dramatic shadow.",
    };
    backgroundPrompt = `ENVIRONMENT: ${presets[background]}`;
    shadowInstructions = `${shadowHardness} matching key light direction.`;
  }

  const fabricMap: Record<FabricType, string> = {
    cotton:  "Heavyweight Cotton Jersey 300GSM. Matte surface. Soft rounded folds. Medium gravity drag.",
    fleece:  "French Terry 500GSM. High structural stiffness. Large tubular compression folds. Fuzzy texture.",
    denim:   "14oz Denim. High rigidity. Angular honeycomb creases at joints. Visible twill weave texture.",
    nylon:   "Ripstop Nylon. Zero-stretch. Paper-crisp crumple. High specular highlights. Noisy fold edges.",
    leather: "Full-grain leather. Very stiff bending. Thick sculpted rounded folds. Subsurface scattering.",
  };
  let materialInstruction = fabricMap[fabricType];
  if (secondaryFabricType !== 'none' && secondaryFabricType !== fabricType) {
    materialInstruction += ` Blend secondary texture characteristics: ${fabricMap[secondaryFabricType]}`;
  }

  const structureMap: Record<GarmentType, string> = {
    't-shirt':    "Drop-shoulder boxy. Fabric drapes vertical from shoulder seam. Slight waist bunching.",
    'hoodie':     "Volumetric air-filled hood. Kangaroo pocket mass. Thick ribbed cuffs and hem.",
    'sweatshirt': "Balloon-fit torso. Tight cuffs create sleeve blousing. Ribbed waistband fold-over.",
    'jacket':     "Internal air pressure (puffer/bomber). Surface tension outward. Deep seam valleys.",
    'pants':      "Wide-leg cascade from hip to floor. Ankle stacking at hem.",
    'shorts':     "A-frame wide cut. Rigid tube legs. Distinct shadow hem line on mid-thigh.",
  };

  const fitMap: Record<FitType, string> = {
    regular:   "Standard drape. Fabric contacts body at shoulder, chest, waist. Moderate fold frequency.",
    oversized: "EXCESS FABRIC SIMULATION. Shoulders drop 3–4 inches. Deep vertical folds. Air gap from body.",
    slim:      "HIGH TENSION. Horizontal whiskering at stress points. Minimal loose folds.",
  };

  const coreTask = modelMode === 'human' ? `
    TASK: PHOTOREALISTIC ON-MODEL SHOOT
    1. Analyze input garment: exact pattern, logo positions, colorway, cut details.
    2. Place this exact garment on a ${modelGender} model (realistic body proportions, neutral pose).
    3. Garment must wrap the body realistically. Seams follow body topology.
    4. Preserve ALL logos/graphics. Warp them to match 3D fabric surface perspective.
    5. Model identity is neutral — face calm, body relaxed.
  ` : `
    TASK: 3D GHOST MANNEQUIN PRODUCT RENDER
    1. INFLATE the 2D garment reference into a full 3D volumetric form.
    2. Ghost mannequin effect: garment appears worn by invisible figure.
       - Neck opening: show interior back of neck label with depth/thickness.
       - Sleeve and hem openings: circular cross-sections with visible fabric thickness.
    3. Full 3D depth shading: chest protrudes forward, sides recede, back curves away.
    4. Map all graphics/logos onto 3D surface with correct perspective distortion.
    5. The garment must NOT look flat. It must have clear Z-depth.
  `;

  const prompt = `
    GENERATE A COMMERCIAL PRODUCT RENDER FROM REFERENCE.

    ══ STEP 1: EXTRACTION ══
    Remove ALL background from input (hanger, bed, floor, wrinkles from lying flat).
    Segment ONLY the garment. Reconstruct as freshly steamed.

    ══ STEP 2: COLOR + PROPORTION LOCK ══
    Extract exact hex/RGB from garment. Output must match exactly.
    Example: beige denim input → beige output (NEVER blue).
    Preserve ALL proportions exactly: wide stays wide, boxy stays boxy.
    Logo dimensions must match source image ratio.

    ══ STEP 3: 3D RENDER ══
    ${coreTask}

    ══ STEP 4: SHOT ANGLE (MANDATORY) ══
    ${shotAngleInstructions[shotAngle]}
    Do NOT default to front view unless shotAngle is 'front'.
    For back/side: reconstruct unseen panels from garment type + construction logic.

    ══ STEP 5: PHYSICS ══
    Gravity: -9.8 m/s². Self-collision on. No fabric clipping.
    Material: ${materialInstruction}
    Structure: ${structureMap[garmentType]}
    Fit: ${fitMap[fitType]}

    ══ STEP 6: ENVIRONMENT ══
    ${backgroundPrompt}
    Shadows: ${shadowInstructions}

    ══ STEP 7: LIGHTING ══
    Main: ${mainLightDesc}
    Rim: ${rimLightDesc}

    ══ STEP 8: COMPOSITION ══
    ${getLuxuryCompositionStrategy()}

    ══ OUTPUT RULES ══
    - Generate a NEW render. Do not output the input image unchanged.
    - Do NOT add garment features not in input.
    - Do NOT change colors, proportions, logos.
    - Garment is the ONLY subject. Fills ~70% of frame.
  `;

  const requestParts: any[] = [{ inlineData: { data: base64Image, mimeType } }];
  if (customBackground?.type === 'image') {
    requestParts.push({ inlineData: { data: customBackground.value, mimeType: customBackground.mimeType } });
  }
  requestParts.push({ text: prompt });

  const response = await ai.models.generateContent({
    model,
    contents: { parts: requestParts },
    config: { imageConfig: { aspectRatio: "1:1" } }
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return part.inlineData.data ?? null;
    }
  }
  throw new Error("No image returned. Check API key tier and model access.");
};

// ─────────────────────────────────────────────
// UPSCALE
// ─────────────────────────────────────────────
export const upscaleImage = async (
  base64Image: string,
  mimeType: string,
  resolution: '2K' | '4K'
): Promise<string | null> => {
  const ai = getAI();
  const model = getImageModel();

  const prompt = `
    TASK: IMAGE ENHANCEMENT — ${resolution} UPSCALE
    Rules:
    - Preserve ALL original content. Do NOT change colors, patterns, logos, text.
    - Enhance only: fiber detail, fabric texture, edge sharpness, noise reduction.
    - Maintain original lighting direction and color temperature.
    - Do NOT hallucinate new details.
    - Output: maximum resolution, clean edges, photorealistic textile surface.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { data: base64Image, mimeType } },
        { text: prompt },
      ],
    },
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return part.inlineData.data ?? null;
    }
  }
  throw new Error("Upscale failed. No image returned.");
};

// ─────────────────────────────────────────────
// VIRTUAL TRY-ON
// ─────────────────────────────────────────────
export const generateVirtualTryOn = async (
  garmentBase64: string,
  modelBase64: string,
  mimeType: string
): Promise<string | null> => {
  const ai = getAI();
  const model = getImageModel();

  const prompt = `
    TASK: VIRTUAL TRY-ON COMPOSITE
    Image 1: Garment (source). Image 2: Person (target).
    OUTPUT: Person from Image 2 wearing garment from Image 1.

    RULES:
    1. Extract garment from Image 1. Ignore hanger, floor, background.
    2. Warp garment to match body shape and pose from Image 2 exactly.
    3. Physics: gravity drapes fabric correctly. Folds at elbows, waist, knees.
    4. Lighting: match key light direction from Image 2 onto garment.
    5. PRESERVE: person's face, skin, hair, identity from Image 2. Do not alter.
    6. PRESERVE: garment color, graphics, logos from Image 1. Do not alter.
    7. Garment must look naturally worn — not composited or pasted on.
    8. High quality photorealistic output.
  `;

  const response = await ai.models.generateContent({
    model,
    contents: {
      parts: [
        { inlineData: { data: garmentBase64, mimeType } },
        { inlineData: { data: modelBase64, mimeType } },
        { text: prompt },
      ],
    },
    config: { imageConfig: { aspectRatio: "3:4" } }
  });

  if (response.candidates?.[0]?.content?.parts) {
    for (const part of response.candidates[0].content.parts) {
      if (part.inlineData) return part.inlineData.data ?? null;
    }
  }
  throw new Error("No try-on image generated.");
};
